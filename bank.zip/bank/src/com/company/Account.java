package com.company;

public class Account {
    private final int accountNo;
    private final String name;
    private double balance;

    public Account(int accountNo, String name, double balance) {
        this.accountNo = accountNo;
        this.name = name;
        this.balance = balance;
    }

//    @Override
//    public String toString() {
//        return "Account{" +
//                "accountNo=" + accountNo +
//                ", name='" + name + '\'' +
//                ", balance=" + balance +
//                '}';
//    }

    synchronized public double getBalance() {
        return balance;
    }

    public int getAccountNo() {
        return accountNo;
    }

    synchronized public void deposit(double amount) throws BankException {
        if (amount <= 0)
            throw new BankException("Deposit amount greater than 0");
        balance += amount;
    }

    synchronized public void withdraw(double amount) throws BankException {
        if (amount <= 0)
            throw new BankException("Deposit amount greater than 0");
        balance -= amount;
    }
}
