package com.company;

public class BankException extends Exception {
    public BankException(String errMessage) {
        super(errMessage);
    }
}
