package com.company;


import java.net.*;
import java.io.*;
import java.util.*;

import static java.util.Map.entry;

public class BankClient {
    private BufferedReader stdIn = null;
    private PrintWriter out;
    private BufferedReader in;

    public BankClient(String hostName, int portNumber) {
        try {
            Socket bankSocket = new Socket(hostName, portNumber);
            out = new PrintWriter(bankSocket.getOutputStream(), true);
            in = new BufferedReader(new InputStreamReader(bankSocket.getInputStream()));
            stdIn = new BufferedReader(new InputStreamReader(System.in));
        } catch (UnknownHostException e) {
            System.err.println("Don't know about host " + hostName);
            System.exit(1);
        } catch (IOException e) {
            System.err.println("Couldn't get I/O for the connection to " + hostName);
            System.exit(1);
        }
    }

    public void send(Map<String, String> payload) {
        out.println(payload);
    }

    public String read() {
        String message = null;
        try {
            message = in.readLine();

        } catch (IOException e) {
            e.printStackTrace();
        }
        return message;
    }


    public void run() {
        try {
            String userInput;
            while ((userInput = stdIn.readLine()) != null) {
                out.println(userInput);
                System.out.println("echo: " + in.readLine());
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void simulateUserA(String hostName, int portNumber, Integer[] accounts, String[] amounts) {
        BankClient bankClient = new BankClient(hostName, portNumber);
        List<Integer> accountCollection = Arrays.asList(accounts);
        String[] commands = new String[]{"deposit", "withdraw"};

        for (int i = 0; i < 10; i++) {
            Collections.shuffle(accountCollection);
            for (Integer account : accountCollection) {
                int index = 0;
                if (i % 2 == 0) index = 1;
                String command = commands[index];
                bankClient.send(Map.ofEntries(
                        entry("amount", amounts[BankClient.randomIndex(amounts.length)]),
                        entry("account1", account.toString()),
                        entry("command", command)
                ));
                System.out.println("echo: " + bankClient.read());
            }
        }
    }

    public static void simulateUserB(String hostName, int portNumber, Integer[] accounts, String[] amounts) {
        BankClient bankClient1 = new BankClient(hostName, portNumber);


        for (Integer account1 : accounts) {
            for (Integer account2 : accounts) {
                if (account1.equals(account2)) continue;

                bankClient1.send(Map.ofEntries(
                        entry("amount", amounts[BankClient.randomIndex(amounts.length)]),
                        entry("account1", account1.toString()),
                        entry("account2", account2.toString()),
                        entry("command", "transfer")
                ));
                System.out.println("echo: " + bankClient1.read());
            }
        }
    }

    static int randomIndex(int maxLength) {
        return (int) (Math.random() * maxLength);
    }

    public static void simulateUserC(String hostName, int portNumber, Integer[] accounts, String[] amounts) {
        BankClient bankClient = new BankClient(hostName, portNumber);

        String[] commands = new String[]{"deposit", "withdraw"};
        for (int i = 0; i < 10; i++) {
            bankClient.send(Map.ofEntries(
                    entry("account1", accounts[BankClient.randomIndex(accounts.length)].toString()),
                    entry("amount", amounts[BankClient.randomIndex(amounts.length)]),
                    entry("command", commands[BankClient.randomIndex(commands.length)])
            ));
            System.out.println("echo: " + bankClient.read());
        }
    }

    public static void main(String[] args) {
        String hostName = "127.0.0.1";
        int portNumber = 4400;
        Integer[] accounts = new Integer[]{458_132, 354_623, 189_321};
        String[] amounts = new String[]{"123.12", "56.32", "78.99", "67.78", "210.01", "89.10", "49.99", "450.49"};

        new Thread(() -> BankClient.simulateUserA(hostName, portNumber, accounts, amounts)).start();
        new Thread(() -> BankClient.simulateUserB(hostName, portNumber, accounts, amounts)).start();
        new Thread(() -> BankClient.simulateUserC(hostName, portNumber, accounts, amounts)).start();
    }
}
