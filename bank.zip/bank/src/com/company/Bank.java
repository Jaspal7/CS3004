package com.company;

public class Bank {
    private final Account account1 = new Account(458_132, "Scorched Earth", 1_000);
    private final Account account2 = new Account(354_623, "Negative Infinity", 1_000);
    private final Account account3 = new Account(189_321, "Cap Theorem", 1_000);

    /**
     * adds value (virtual) money to the specified account (i.e. the user’s account – you can assume that they only add money to their own account).
     *
     * @param account bank account to deposit money
     * @param amount  amount to deposit
     * @return deposit status
     */
    String addMoney(Account account, Double amount) {
        try {
            account.deposit(amount);
        } catch (BankException e) {
            return e.getMessage();
        }
        return String.format("Deposit of %f from account %d successful!", amount, account.getAccountNo());
    }

    /**
     * subtracts value (virtual) money from the specified account (i.e. the user’s account – you can assume that they only subtract money from their own account).
     *
     * @param account bank account to withdraw money
     * @param amount  amount to withdraw
     * @return withdrawal status
     */
    public String subtractMoney(Account account, Double amount) {
        try {
            account.withdraw(amount);
        } catch (BankException e) {
            return e.getMessage();
        }
        return String.format("Withdrawal of %f from account %d successful!", amount, account.getAccountNo());
    }

    /**
     * transfers value (virtual) money from account1 to account2.
     *
     * @param account_1 account to remove money to transfer
     * @param account_2 account to deposit the money
     * @param amount    amount to transfer to second account
     * @return transfer status
     */
    public String transferMoney(Account account_1, Account account_2, double amount) {
        try {
            synchronized (this) {
                account_1.withdraw(amount);
                account_2.deposit(amount);
                return String.format("Transfer of %f from account %d to account %d successful!",
                        amount, account_1.getAccountNo(), account_2.getAccountNo()
                );
            }
        } catch (BankException e) {
            return e.getMessage();
        }
    }

    /**
     * Return account with a given account number.
     *
     * @param accountNo account unique number
     * @return account object if found or null
     */
    public Account getAccount(int accountNo) {
        switch (accountNo) {
            case 458_132:
                return account1;
            case 354_623:
                return account2;
            case 189_321:
                return account3;
            default:
                return null;
        }
    }
}
