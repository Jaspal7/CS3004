package com.company;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.HashMap;
import java.util.Map;

public class BankServer {
    static class ClientHandler implements Runnable {
        private final Socket clientSocket;
        private final int portNumber;
        private final Bank bank = new Bank();

        public ClientHandler(Socket clientSocket, int portNumber) {
            this.clientSocket = clientSocket;
            this.portNumber = portNumber;
        }

        String processPayload(Map<String, String> payload) {
            Account account1 = bank.getAccount(Integer.parseInt(payload.get("account1")));
            Double amount = Double.parseDouble(payload.get("amount"));
            String response = "";
            switch (payload.get("command")) {
                case "deposit":
                    response = bank.addMoney(account1, amount);
                    break;
                case "withdraw":
                    response = bank.subtractMoney(account1, amount);
                    break;
                case "transfer":
                    Account account2 = bank.getAccount(Integer.parseInt(payload.get("account2")));
                    response = bank.transferMoney(account1, account2, amount);
                    break;
            }
            return  response;
        }

        Map<String, String> createPayloadMap(String payload) {
            Map<String, String> m = new HashMap<>();
            for (String kv : payload.substring(1, payload.length() - 1).split(",")) {
                String[] kv_arr = kv.split("=");
                m.put(kv_arr[0].strip(), kv_arr[1].strip());
            }
            return m;
        }

        @Override
        public void run() {
            try (
                    PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true);
                    BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()))
            ) {

                String inputLine;
                while ((inputLine = in.readLine()) != null) {
                    Map<String, String> payload = createPayloadMap(inputLine);
//                    System.out.println("payload: " + payload);
                    System.out.println(processPayload(payload));
                    out.println(payload);
                }
            } catch (IOException e) {
                System.out.println("Exception caught when trying to listen on port "
                        + portNumber + " or listening for a connection");
                System.out.println(e.getMessage());
            }
        }
    }

    public static void main(String[] args) {

        if (args.length != 1) {
            System.err.println("Usage: java EchoServer <port number>");
            System.exit(1);
        }

        int portNumber = Integer.parseInt(args[0]);
        try {
            ServerSocket serverSocket = new ServerSocket(portNumber);
            serverSocket.setReuseAddress(true);

            System.out.println("Server ready for connection");
            while (true) {
                Socket clientSocket = serverSocket.accept();
                System.out.printf("New connection: %s:%d%n", clientSocket.getInetAddress().getHostAddress(), clientSocket.getPort());
                new Thread(new ClientHandler(clientSocket, portNumber)).start();
            }
        } catch (IOException e) {
            System.out.println("Exception caught when trying to listen on port "
                    + portNumber + " or listening for a connection");
            System.out.println(e.getMessage());
        }
    }
}
